# ShyKnight

A mod that removes the animated background audience from godhome arenas. Makes it easier to focus on the foreground.